import React, { useEffect, useState } from 'react'
import Axios  from 'axios'
import { useNavigate } from 'react-router-dom'


const Home = () => {
  let [users,setUsers]=useState(null)
  let navigate=useNavigate()
  useEffect(()=>{
    let fetchData=async()=>{
      let {data}=await Axios.get("http://localhost:3000/user-data")
      setUsers(data)
    }
    fetchData()
  },[])
  let handleCreateUser=()=>{
    navigate("/create")
  }

  let handleRead=(id)=>{
    navigate(`/read/${id}`)
  }

  let handleDelete=(id)=>{
    Axios.delete(`http://localhost:3000/user-data/${id}`)
    location.reload()
  }

  let handleEdit = (id)=>{
    navigate(`/edit/${id}`)
  }
  
  return (
    <>
    <button onClick={handleCreateUser}>ADD USER➕</button>
    <table width='100%' border={5}>
    <thead>
      <tr>
        <th>SL NO</th>
        <th>NAME</th>
        <th>DEGREE</th>
        <th>STREAM</th>
        <th>PERCENTAGE</th>
        <th>CONTACT</th>
      </tr>
   </thead>
   <tbody>
    {users==null?<tr><td>Loading....</td></tr>:users.map((ele,ind)=>{
      return <tr key={ele.id}>
        <td>{ind+1}</td>
        <td>{ele.name}</td>
        <td>{ele.degree}</td>
        <td>{ele.stream}</td>
        <td>{ele.percentage}</td>
        <td>{ele.contact}</td>
        <td><button onClick={()=>handleEdit(ele.id)}>EDIT</button></td>
        <td><button onClick={()=>handleRead(ele.id)}>READ</button></td>
        <td><button onClick={()=>handleDelete(ele.id)}>DELETE</button></td>
      </tr>
     })
    }
   </tbody>
   </table>
    </>
    
  )
}

export default Home